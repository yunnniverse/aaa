#!/usr/bin/env python3
"""Regenerate the six final MCOZ accuracy figures.

Edit the constants near the top to adjust figure size, font size, line width,
axis limits, and output formats for all six plots in one place.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "out"

# Global style knobs. These match the final social/media notebook style by default.
FIG_WIDTH = 2.2
FIG_HEIGHT = 1.55
DPI = 300
FONT_FAMILY = "Times New Roman"
LABEL_FONT_SIZE = 10
TICK_FONT_SIZE = 9
LINE_WIDTH = 1.75
MARKER_SIZE = 3.8
ERROR_LINE_WIDTH = 0.85
CAP_SIZE = 1.9
CAP_THICK = 0.8

# Absolute layout knobs, in inches.
# FIG_WIDTH/FIG_HEIGHT define the whole PDF canvas.
# AXIS_WIDTH/AXIS_HEIGHT define only the actual plotting box.
# LEFT_MARGIN/BOTTOM_MARGIN place the plotting box inside the canvas.
AXIS_WIDTH = 1.5
AXIS_HEIGHT = 0.9
LEFT_MARGIN = 0.5
BOTTOM_MARGIN = 0.55

OUTPUT_FORMAT = "pdf"


@dataclass(frozen=True)
class PlotSpec:
    name: str
    csv_name: str
    x_ticks: tuple[float, ...]
    y_ticks: tuple[float, ...]
    y_lim: tuple[float, float]
    x_lim: tuple[float, float] | None = None


SPECS: tuple[PlotSpec, ...] = (
    PlotSpec(
        name="media_target_user_bottleneck",
        csv_name="media_target_user_bottleneck.csv",
        x_ticks=(1, 1.5, 2, 2.5, 3),
        y_ticks=(0.5, 1, 1.5, 2, 2.5, 3),
        y_lim=(0.0, 3.65),
        x_lim=(0.9, 3.1),
    ),
    PlotSpec(
        name="media_target_movie_non_bottleneck",
        csv_name="media_target_movie_non_bottleneck.csv",
        x_ticks=(1, 1.5, 2, 2.5, 3),
        y_ticks=(-2, -1, 0, 1, 2),
        y_lim=(-2.0, 2.0),
        x_lim=(0.9, 3.1),
    ),
    PlotSpec(
        name="social_target_uniqueid_bottleneck",
        csv_name="social_target_uniqueid_bottleneck.csv",
        x_ticks=(1, 1.5, 2, 2.5, 3),
        y_ticks=(0, 1, 2, 3, 4),
        y_lim=(-0.2, 4.2),
        x_lim=(0.9, 3.1),
    ),
    PlotSpec(
        name="social_target_media_non_bottleneck",
        csv_name="social_target_media_non_bottleneck.csv",
        x_ticks=(1, 1.5, 2, 2.5, 3),
        y_ticks=(-2, -1, 0, 1, 2),
        y_lim=(-2.0, 2.0),
        x_lim=(0.9, 3.1),
    ),
    PlotSpec(
        name="train_target_service1_bottleneck",
        csv_name="train_target_service1_bottleneck.csv",
        x_ticks=(5, 10, 15, 20),
        y_ticks=(0, 5, 10, 15, 20, 25),
        y_lim=(-2.0, 27.0),
        x_lim=(4, 21),
    ),
    PlotSpec(
        name="train_target_service2_non_bottleneck",
        csv_name="train_target_service2_non_bottleneck.csv",
        x_ticks=(5, 10, 15, 20),
        y_ticks=(-10, -5, 0, 5, 10),
        y_lim=(-10.0, 10.0),
        x_lim=(4, 21),
    ),
)


def configure_matplotlib() -> None:
    plt.rcParams["font.family"] = FONT_FAMILY
    plt.rcParams["pdf.fonttype"] = 42
    plt.rcParams["ps.fonttype"] = 42


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Use one internal column naming scheme for DeathStarBench and TrainTicket."""
    if "actual_gain_mean_ms" in df.columns:
        x_col = "virtual_delay_ms" if "virtual_delay_ms" in df.columns else "effective_delta_ms"
        if x_col not in df.columns:
            x_col = "delta_ms"
        return pd.DataFrame(
            {
                "delta_ms": df[x_col],
                "actual_gain_ms": df["actual_gain_mean_ms"],
                "actual_error_ms": df["actual_gain_ci95_ms"],
                "virtual_gain_ms": df["virtual_gain_mean_ms"],
                "virtual_error_ms": df["virtual_gain_ci95_ms"],
            }
        )
    return df[
        [
            "delta_ms",
            "actual_gain_ms",
            "actual_error_ms",
            "virtual_gain_ms",
            "virtual_error_ms",
        ]
    ].copy()


def plot_one(spec: PlotSpec) -> None:
    df = normalize_columns(pd.read_csv(DATA_DIR / spec.csv_name))
    fig = plt.figure(figsize=(FIG_WIDTH, FIG_HEIGHT), dpi=DPI)
    ax = fig.add_axes(
        [
            LEFT_MARGIN / FIG_WIDTH,
            BOTTOM_MARGIN / FIG_HEIGHT,
            AXIS_WIDTH / FIG_WIDTH,
            AXIS_HEIGHT / FIG_HEIGHT,
        ]
    )

    ax.axhline(0, color="#6B7280", linewidth=0.75, alpha=0.85, zorder=0)
    ax.errorbar(
        df["delta_ms"],
        df["actual_gain_ms"],
        yerr=df["actual_error_ms"],
        color="#0072B2",
        marker="o",
        linewidth=LINE_WIDTH,
        markersize=MARKER_SIZE,
        markerfacecolor="white",
        markeredgewidth=1.0,
        elinewidth=ERROR_LINE_WIDTH,
        capsize=CAP_SIZE,
        capthick=CAP_THICK,
        label="Actual Optimization",
    )
    ax.errorbar(
        df["delta_ms"],
        df["virtual_gain_ms"],
        yerr=df["virtual_error_ms"],
        color="#D55E00",
        marker="s",
        linewidth=LINE_WIDTH,
        markersize=MARKER_SIZE,
        markerfacecolor="white",
        markeredgewidth=1.0,
        elinewidth=ERROR_LINE_WIDTH,
        capsize=CAP_SIZE,
        capthick=CAP_THICK,
        label="MCOZ",
    )

    ax.set_ylabel("Latency Gain (ms)", fontsize=LABEL_FONT_SIZE)
    ax.set_xlabel("Target execution-time\nreduction (ms)", fontsize=LABEL_FONT_SIZE)
    ax.set_xticks(spec.x_ticks)
    ax.set_yticks(spec.y_ticks)
    ax.set_ylim(*spec.y_lim)
    if spec.x_lim is not None:
        ax.set_xlim(*spec.x_lim)
    ax.tick_params(axis="both", labelsize=TICK_FONT_SIZE, pad=2)

    ax.grid(True, axis="y", color="#D8DEE9", linewidth=0.7, alpha=0.9)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT_DIR / f"{spec.name}.{OUTPUT_FORMAT}", transparent=True)
    plt.close(fig)


def main() -> None:
    configure_matplotlib()
    for spec in SPECS:
        plot_one(spec)
    print(f"Wrote {len(SPECS)} PDF files to {OUT_DIR}")


if __name__ == "__main__":
    main()
