# Final Six Figure Plotter

This folder contains copied CSV inputs and one script to regenerate the six final
MCOZ accuracy figures:

- `media_target_user_bottleneck`
- `media_target_movie_non_bottleneck`
- `social_target_uniqueid_bottleneck`
- `social_target_media_non_bottleneck`
- `train_target_service1_bottleneck`
- `train_target_service2_non_bottleneck`

Edit `plot_all_six.py` near the top to adjust:

- `FIG_WIDTH`, `FIG_HEIGHT`
- `LABEL_FONT_SIZE`, `TICK_FONT_SIZE`
- line, marker, and error-bar sizes
- each figure's `y_lim` and `y_ticks` in `SPECS`

Regenerate PDF figures:

```bash
python3 /home/sopia0821/second_graph/final_six_plotter/plot_all_six.py
```

Outputs are written to:

```text
/home/sopia0821/second_graph/final_six_plotter/out
```
